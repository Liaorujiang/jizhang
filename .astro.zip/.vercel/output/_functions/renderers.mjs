const renderers = [];

export { renderers };
