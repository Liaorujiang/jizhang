const server = {};

export { server };
