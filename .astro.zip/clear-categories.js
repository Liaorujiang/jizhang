// 清空本地存储中的分类数据
localStorage.removeItem('categories');
console.log('分类数据已清空，刷新页面后将使用新的默认分类');
